function[Pg,Gbest,cg_curvepso]=EHVPSO(setpop,Max_FES,dim,N,low,up,fobj)
t0=cputime;
FES=0;
c1 = 2;
c2 = 2;
a=0.9;
b=0.4;
m1=2;
m2=1;
m3=0.5;
min_flag=1;
Vmax=up;
Vmin=low;
BestChart1=[];
Meanfitness1=[];
item=1;
cg_curvepso=[];
X=setpop; 

     BestChart=[];Meanfitness=[];
     V=zeros(N,dim);
     for i=1:size(X,1)
       fitness(1,i)=fobj(X(i,:));
       FES=FES+1;
     end
     
     Ibest=fitness;
     Pi=X;

     if min_flag==1
        [best best_X]=min(fitness); 
     else
        [best best_X]=max(fitness); %maximization.
     end        
     
     Gbest=best;
     Pg=X(best_X,:);

   
while FES <= Max_FES
        f1=1-m1*FES/Max_FES;
        f2=sqrt(Max_FES^2-FES^2)*2*m2/Max_FES;
        f3=sqrt(Max_FES^2-FES^2)*2*m3/Max_FES;
        w=b+(a-b)*(FES/Max_FES);
        
        for j=1:N
        
            V(j,:) = w*V(j,:) + c1*rand*(Pi(j,:) - X(j,:)) + c2*rand*(Pg - X(j,:));
            V(j,find(V(j,:)>Vmax))=Vmax;
            V(j,find(V(j,:)<Vmin))=Vmin;


            X(j,:)=X(j,:)+V(j,:);

            for m=1:dim
                if X(j,m)>up ||X(j,m)<low
                    X(j,m)=up*f1+(Pg(m)-rand*X(j,m)*f2)+(Pi(j,m)-rand*X(j,m)*f3);
                end
                
            end

        end
        for m=1:size(X,1)
          fitness(1,m)=fobj(X(m,:));
          FES=FES+1;
        end
        for j=1:N

         
            if fitness(j) < Ibest(j)
                Pi(j,:) = X(j,:);
                Ibest(j) = fitness(j);
            end

       
            if fitness(j) < Gbest
                Pg = X(j,:);
                Gbest = fitness(j);
            end
        end 
        
        BestChart=[BestChart Gbest]; Meanfitness=[Meanfitness mean(fitness)];
        
        cg_curvepso(item)=Gbest;

        disp(['IterationEHVPSO ' num2str(item) ': Best Cost = ' num2str(Gbest)]);
        item=item+1;
end
    BestChart1=[BestChart1;BestChart]; 
    Meanfitness1=[Meanfitness1;Meanfitness];
    t=cputime-t0;

