% Water Drop Optimizer (WDO)

%  ZhenDong Liu, YiMing Fang ,Le Liu, XiaoDong Zhao
%  Key Lab of Industrial Computer Control Engineering of Hebei Province, Yanshan University, Qinhuangdao 066004, China.
%  Research Center of the Ministry of Education for Intelligent Control System and Intelligent Equipment, Yanshan University, Qinhuangdao 066004, China.

%  Last update:  August  31, 2022

%  e-Mail:zhendong101671@126.com
%  e-Mail:fyming@ysu.edu.cn


%  Note: The termination condition uses the number of evaluations
%---------------------------------------------------------------------------------------------------------------------------

function [gbest,gbestval,cg_curvewdo]= WDO(setpop,Max_FES,Dimension,Particle_Number,VRmin,VRmax,fobj)
FES=0;% Record the number of evaluations
epss=eps;
Nwater=setpop;% Initialization
item=1;
pp=0.1;% diffusion factor
Max_Nwater=5;% upper limit 
Min_Nwater=2;% lower limit
for i=1:size(Nwater,1)
e(1,i)=fobj(Nwater(i,:));
end
FES=FES+Particle_Number;

[fitness1,SortOrder1]=sort(e);
Nwater=Nwater(SortOrder1,:);

while FES <= Max_FES 
% Used to store the total number of water drops 
smallwater=0;
% Distance factor
T=2*unifrnd(-1,1)*(1-(FES/Max_FES)+eps);
% Diffusion
if abs(T)<=1
    for i = 1:round(Particle_Number*pp)     
    
    lmabda=round(rand*Particle_Number*(fitness1(i)-max(fitness1)+epss)/(sum(fitness1)-Particle_Number*max(fitness1)+epss));
    
    if lmabda > Max_Nwater
        lmabda = Max_Nwater;
    elseif lmabda < Min_Nwater
        lmabda = Min_Nwater;
    end 
    
    smallwater=smallwater+lmabda;
    
    s=ones(lmabda,Dimension)*nan;
    for j=1:lmabda
          k=ceil(rand*(Particle_Number-1))+1;
          for m=1:Dimension
              s(j,m)=Nwater(i,m)+log(1/rand)*cos(rand*pi)*sin(2*rand*pi)*(Nwater(1,m)-Nwater(k,m));%���ΰ뾶��ģ�³����壩
              
              if s(j,m)>VRmax                  
                  s(j,m)=VRmax- rand*(VRmax-VRmin); 
              end
              if s(j,m)<VRmin
                  s(j,m)=VRmin+ rand*(VRmax-VRmin);
              end
          end 
     end        
     Nwater=[Nwater
                  s]; 
    end 
end
e=zeros(1,size(Nwater,1))*nan;
for i=1:Particle_Number
e(1,i)=fitness1(1,i);
end
for i=(Particle_Number+1):size(Nwater,1)
e(1,i)=fobj(Nwater(i,:));
end
FES=FES+size(Nwater,1)-Particle_Number;
[eeee, SortOrder2]=sort(e);
Nwater=Nwater(SortOrder2,:);
% Flow
Xm=mean(Nwater);
for i=2:size(Nwater,1)     
    NU=randperm(Particle_Number+smallwater,1);     
    vector1=zeros(1,Dimension)*nan;
    vector2=zeros(1,Dimension)*nan;
    vector3=zeros(1,Dimension)*nan;
       
        if abs(T)>1
            if rand <= 0.5
              for j=1:Dimension
                vector1(1,j)=Nwater(NU,j)-rand*abs(Nwater(NU,j)-2*rand*Nwater(i,j));                
                if vector1(1,j)>VRmax                  
                vector1(1,j)=VRmax- rand*(VRmax-VRmin); 
                end
                if vector1(1,j)<VRmin
                vector1(1,j)=VRmin+ rand*(VRmax-VRmin);
                end
              end
              ee1=fobj(vector1(1,:));
              FES=FES+1;
              Nwater(i,:)=vector1(1,:);
              eeee(i)=ee1;
            else
                for j=1:Dimension
                vector2(1,j)=Nwater(1,j)-Nwater(i-1,j)-rand*(VRmin+rand*(VRmax-VRmin));
                if vector2(1,j)>VRmax                  
                vector2(1,j)=VRmax- rand*(VRmax-VRmin); 
                end
                if vector2(1,j)<VRmin
                vector2(1,j)=VRmin+ rand*(VRmax-VRmin);
                end
                end
                ee2=fobj(vector2(1,:));
                FES=FES+1;
                Nwater(i,:)=vector2(1,:);
                eeee(i)=ee2;
            end
        end        
        if abs(T)<=1 
           for j=1:Dimension
               vector3(1,j)=Nwater(i,j)+log(1/rand)*((Nwater(1,j)-Nwater(i,j)))+rand*(Nwater(2,j)-Nwater(i,j))+rand*(Xm(1,j)-Nwater(i,j));
               if vector3(1,j)>VRmax                  
               vector3(1,j)=VRmax- rand*(VRmax-VRmin); 
               end
               if vector3(1,j)<VRmin
               vector3(1,j)=VRmin+ rand*(VRmax-VRmin);
               end
           end         
            ee3=fobj(vector3(1,:));
            FES=FES+1;

            if ee3 < eeee(i)
              Nwater(i,:)=vector3(1,:);
              eeee(i)=ee3;
            end       
        end  
end
[eee, SortOrder3]=sort(eeee);
Nwater=Nwater(SortOrder3,:);
% Evaporation
Nwater=Nwater(1:Particle_Number,:);
fitness1=eee(1,1:Particle_Number);
gbest=Nwater(1,:);
gbestval=min(eee);
cg_curvewdo(item)=gbestval;
% Show iteration information
disp(['Iteration WDO ' num2str(item) ': Best Cost = ' num2str(gbestval)]);
item=item+1;
end 
end

