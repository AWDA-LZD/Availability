%_________________________________________________________________________%
%SFO  Sailfish optimizer           %
%_________________________________________________________________________%
function [Best_pos,Best_score,curve]=SFO(setpop,Max_FES,dim,pop,lb,ub,fobj)
FES=0;
A = 4;
e = 0.001;
SFpercent = 0.3;
SFNumber = round(pop*0.3);
SNumber = pop - SFNumber;
if(max(size(ub)) == 1)
   ub = ub.*ones(1,dim);
   lb = lb.*ones(1,dim);  
end
XSF0 = setpop;%sailfish 
XS0 = initialization(SNumber,dim,ub,lb);%sardines 
XSF = XSF0;
XS = XS0;
fitnessSF = zeros(1,SFNumber);
fitnessS = zeros(1,SNumber);
for i = 1:size(XSF,1)
   fitnessSF(i) =  fobj(XSF(i,:));
   FES=FES+1;
end
for i = 1:size(XS,1)
   fitnessS(i) = fobj(XS(i,:));
   FES=FES+1;
end

 [fitnessSF, indexSF]= sort(fitnessSF);
 Xelite = XSF(indexSF(1),:);%sailfish 
 
 [fitnessS, indexS]= sort(fitnessS);
 Xinjured = XS(indexS(1),:);%sardines 

 XSF = XSF(indexSF,:);
 XS = XS(indexS,:);

 if(fitnessSF(1)<fitnessS(1))
    GBestX = XSF(1,:);
    GBestF = fitnessSF(1);
 else
     GBestX = XS(1,:);
     GBestF = fitnessS(1);
 end

XSFnew = XSF;
XSnew = XS;
t=1;
while FES<= Max_FES

    PD = 1 - (size(XSF,1)/(size(XSF,1) + size(XS,1)));
    lamda = 2*rand()*PD - PD;
    for i = 1:size(XSFnew,1)
       XSFnew(i,:) =  Xelite - lamda.*(rand().*((Xelite + Xinjured)./2)-XSF(i,:));
    end

    AP = A*(1-(2*t*e));
    if(AP<0.5)
        alpha = max(round(size(XS,1)*AP),1);
        beta = max(round(dim*AP),1);
        indexRandom = randperm(size(XS,1),alpha);
        for i = 1:alpha
         XSnew(indexRandom(i),1:beta) = rand().*(Xelite(1:beta) - XS(indexRandom(i),1:beta) + AP);
        end
    else
         for i = 1:size(XSnew,1)
         XSnew(i,:) = rand().*(Xelite - XS(i,:) + AP);
         end
    end

   for j = 1:size(XSFnew,1)
       for a = 1: dim
           if(XSFnew(j,a)>ub)
               XSFnew(j,a) =ub(a);
           end
           if(XSFnew(j,a)<lb)
               XSFnew(j,a) =lb(a);
           end
       end
   end 
    for j = 1:size(XSnew,1)
       for a = 1: dim
           if(XSnew(j,a)>ub)
               XSnew(j,a) =ub(a);
           end
           if(XSnew(j,a)<lb)
               XSnew(j,a) =lb(a);
           end
       end
   end 

    for i = 1:size(XSF,1)
     fitnessSF(i) =  fobj(XSFnew(i,:));
     FES=FES+1;
    end
    for i = 1:size(XS,1)
     fitnessS(i) = fobj(XSnew(i,:));
     FES=FES+1;
    end

    deleteIndex = zeros(1,size(XSnew,1));
    for i = 1:min(size(XSFnew,1),size(XSnew,1))
        if(fitnessS(i)<fitnessSF(i))
           XSFnew(i,:) = XSnew(i,:);
           deleteIndex(i) = 1;
        end
    end

    for i = 1:size(XSnew,1)
       if(deleteIndex(i) == 1)
           XSnew(i,:) = rand(1,dim).*(ub-lb)+lb;
       end
    end
    for i = 1:size(XS,1)
     fitnessS(i) = fobj(XSnew(i,:));
     FES=FES+1;
    end
    XSF = XSFnew;
    XS  = XSnew;
  [fitnessSF, indexSF]= sort(fitnessSF);
 Xelite = XSF(indexSF(1),:);
 [fitnessS, indexS]= sort(fitnessS);
 Xinjured = XS(indexS(1),:);

 XSF = XSF(indexSF,:);
 XS = XS(indexS,:);

 if(fitnessSF(1)<fitnessS(1))
    LocalGBestX = XSF(1,:);
    LocalGBestF = fitnessSF(1);
 else
     LocalGBestX = XS(1,:);
     LocalGBestF = fitnessS(1);
 end
 if(LocalGBestF<GBestF)
     GBestF = LocalGBestF;
     GBestX = LocalGBestX;
 end
    curve(t) = GBestF;
    disp(['IterationSFO ' num2str(t) ': Best Cost = ' num2str(GBestF)]);
    t=t+1;
end
Best_pos = GBestX;
Best_score = curve(end);
end



