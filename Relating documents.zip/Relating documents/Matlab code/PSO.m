function[Pg,Gbest,cg_curvepso]=PSO(setpop,Max_FES,dim,N,low,up,fobj)

FES=0;
c1 = 2;
c2 = 2;
min_flag=1;
Vmax=up;
Vmin=low;
BestChart1=[];
Meanfitness1=[];
item=1;
X=setpop; 
%create the Average best so far chart and average fitnesses chart.
BestChart=[];Meanfitness=[];
V=zeros(N,dim);
for i=1:size(X,1)
   fitness(1,i)=fobj(X(i,:));
   FES=FES+1;
end     
Ibest=fitness;
Pi=X;    
if min_flag==1
   [best best_X]=min(fitness);
else
   [best best_X]=max(fitness); 
end        
Gbest=best;
Pg=X(best_X,:);
while FES <= Max_FES
        b=(900-0.2)/999;
        a=0.9-b;
        w=a*item+b;              
        for j=1:N           
           V(j,:) = w*V(j,:) + c1*rand*(Pi(j,:) - X(j,:)) + c2*rand*(Pg - X(j,:));
           V(j,find(V(j,:)>Vmax))=Vmax;
           V(j,find(V(j,:)<Vmin))=Vmin;
           X(j,:)=X(j,:)+V(j,:);
           X=space_boundPSO(X,up,low); 
        end
        for m=1:size(X,1)
          fitness(1,m)=fobj(X(m,:));
          FES=FES+1;
        end
        for j=1:N
            
            if fitness(j) < Ibest(j)
                Pi(j,:) = X(j,:);
                Ibest(j) = fitness(j);
            end
            if fitness(j) < Gbest
                Pg = X(j,:);
                Gbest = fitness(j);
            end
        end           
        BestChart=[BestChart Gbest]; Meanfitness=[Meanfitness mean(fitness)];
        cg_curvepso(item)=Gbest;
        disp(['IterationPSO ' num2str(item) ': Best Cost = ' num2str(Gbest)]);
        item=item+1;
end
    BestChart1=[BestChart1;BestChart]; 
    Meanfitness1=[Meanfitness1;Meanfitness];


