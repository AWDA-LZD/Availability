% Water Drop Optimizer (WDO) and some other competition algorithms 

%  ZhenDong Liu, YiMing Fang ,Le Liu, XiaoDong Zhao
%  Key Lab of Industrial Computer Control Engineering of Hebei Province, Yanshan University, Qinhuangdao 066004, China.
%  Research Center of the Ministry of Education for Intelligent Control System and Intelligent Equipment, Yanshan University, Qinhuangdao 066004, China.

%  Last update:  August  31, 2022

%  e-Mail:zhendong101671@126.com
%  e-Mail:fyming@ysu.edu.cn

%  Note: The termination condition uses the number of evaluations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%clear all;clc

% Population size
pop_size=20;
% Number of runs
runs=1;
% Name of the test function that can be from F1 to F23
Function_name='F1'; 
% Load details of the selected benchmark function
[LB,UB,D,fobj]=Benchmark_Functions(Function_name);
% Maximum number of evaluations
Max_FES=10000*D;

for j=1:runs
              
        %Initialize the population
        setpop=initialization(pop_size,D,UB,LB);
        
        %WDO
        [gbestwdo,gbestvalwdo,cg_curvewdo]= WDO(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestwdo(j,:)=gbestwdo;
        fbestwdo(j)=gbestvalwdo;
        fbestwdo(j);
        
        %DE
        [gbestde,gbestvalde,cg_curvede]= DE(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestde(j,:)=gbestde;
        fbestde(j)=gbestvalde;
        fbestde(j);
        
        %PSO
        [gbestpso,gbestvalpso,cg_curvepso]= PSO(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestpso(j,:)=gbestpso;
        fbestpso(j)=gbestvalpso;
        fbestpso(j);
        
        %SFO
        [gbestsfo,gbestvalsfo,cg_curvesfo]= SFO(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestsfo(j,:)=gbestsfo;
        fbestsfo(j)=gbestvalsfo;
        fbestsfo(j);
        
        %MA
        [gbestma,gbestvalma,cg_curvema]= MA(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestma(j,:)=gbestma;
        fbestma(j)=gbestvalma;
        fbestma(j);  
        
        %SSA
        [gbestssa,gbestvalssa,cg_curvessa]= SSA(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestssa(j,:)=gbestssa;
        fbestssa(j)=gbestvalssa;
        fbestssa(j);
        
        %CPA
        [gbestcpa,gbestvalcpa,cg_curvecpa]= CPA(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestcpa(j,:)=gbestcpa;
        fbestcpa(j)=gbestvalcpa;
        fbestcpa(j);
        
        %EHVPSO
        [gbestehvpso,gbestvalehvpso,cg_curveehvpso]= EHVPSO(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestehvpso(j,:)=gbestehvpso;
        fbestehvpso(j)=gbestvalehvpso;
        fbestehvpso(j);
        
        %IGWO
        [gbestigwo,gbestvaligwo,cg_curveigwo]= IGWO(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestigwo(j,:)=gbestigwo;
        fbestigwo(j)=gbestvaligwo;
        fbestigwo(j);
            
        %LFD
        [gbestlfd,gbestvallfd,cg_curvelfd]= LFD(setpop,Max_FES,D,pop_size,LB,UB,fobj);
        xbestlfd(j,:)=gbestlfd;
        fbestlfd(j)=gbestvallfd;
        fbestlfd(j);
           
end
    
%% Get the results 
disp(['The optimal value of WDO is :  ' num2str(fbestwdo)]);
disp(['The optimal value of DE is :  ' num2str(fbestde)]);
disp(['The optimal value of PSO is :  ' num2str(fbestpso)]);
disp(['The optimal value of SFO is :  ' num2str(fbestsfo)]);
disp(['The optimal value of MA is :  ' num2str(fbestma)]);
disp(['The optimal value of SSA is :  ' num2str(fbestssa)]);
disp(['The optimal value of CPA is :  ' num2str(fbestcpa)]);
disp(['The optimal value of EHVPSO is :  ' num2str(fbestehvpso)]);
disp(['The optimal value of IGWO is :  ' num2str(fbestigwo)]);
disp(['The optimal value of LFD is :  ' num2str(fbestlfd)]);