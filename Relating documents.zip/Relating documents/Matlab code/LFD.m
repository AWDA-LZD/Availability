% Developed in MATLAB R2014b
%_________________________________________________________________
%   L\'evy flight distribution (LFD) source code
%  programming: Mohammed R. Saad and Fatma A. Hashim
%
%  paper:
%  Essam H. Houssein, Mohammed R. Saad, Fatma A. Hashim,
%  Hassan Shaban, and M. Hassaballah
%  L´evy Flight Distribution: A new metaheuristic algorithm for    %  solving engineering optimization problems
%  Engineering Applications of Artificial Intelligence
%  DOI:
%
%  E-mail: essam.halim@mu.edu.eg (Essam H. Houssein)
%  E-mail: m.saad@fci.svu.edu.eg (Mohammed R. Saad)
%  E-mail: fatma_hashim@h-eng.helwan.edu.eg (Fatma A. Hashim)
%  E-mail: hassan_sh_ha@yahoo.com (Hassan Shaban)
%  E-mail: m.hassaballah@svu.edu.eg (M. Hassaballah)
%________________________________________________________________

function [TargetPosition,TargetFitness,conver_iter]=LFD(setpop,Max_FES,dim,N,lb,ub,fobj)
t0=cputime;
threshold=2;
FES=0;
% Lower bounds
lb=lb*ones(1,dim);
% Upper bounds
ub=ub*ones(1,dim);
if size(ub,1)==1
    ub=ones(dim,1)*ub;
    lb=ones(dim,1)*lb;
end
Positions=setpop;

PositionsFitness = zeros(1,N);
Positions_temp=Positions;

for i=1:size(Positions,1)
    PositionsFitness(1,i) = fobj(Positions(i,:));
    FES=FES+1;
end
[sorted_fitness,sorted_indexes]=min(PositionsFitness);
TargetPosition=Positions(sorted_indexes,:);
TargetFitness=sorted_fitness;
vec_flag=[1,-1];
NN=[0,1];
% Main loop
conver_iter(1)=TargetFitness;
l=1;
while FES<=Max_FES
    for i=1:size(Positions,1)
        FU= Positions(i,:)>ub(1,dim);FL= Positions(i,:)<lb(1,dim); Positions(i,:)=( Positions(i,:).*(~(FU+FL)))+ub(1,dim).*FU+lb(1,dim).*FL;
        S_i=zeros(1,dim);
        NeighborN=0;
        for j=1:N
            
            if i~=j
                dis = norm(Positions(j,:)-Positions(i,:));
                if (dis<threshold)
                    temp=(PositionsFitness(j)/(PositionsFitness(i)+eps));
                    temp=((.9*(temp-min(temp)))./(max(temp(:))-min(temp)+eps))+.1;
                    NeighborN=NeighborN+1;
                    D(NeighborN)=temp;
                    pos_temp_nei{NeighborN}=Positions(j,:);
                    
                    R=rand();
                    CSV=.5;
                    if R<CSV
                        rand_leader_index = randi(N);
                        X_rand = Positions(rand_leader_index, :);
                        Positions_temp(j,:)=LF(Positions(j,:),X_rand,dim);
                    else
                        Positions_temp(j,:)=lb(1)+rand(1,dim)*(ub(1)-lb(1));
                    end
                end
            end
        end
        for p=1:NeighborN
            flag_index = floor(2*rand()+1);
            var_flag=vec_flag(flag_index);
            s_ij=var_flag*D(p).*(pos_temp_nei{p})/NeighborN;
            S_i=S_i+s_ij;
        end
        S_i_total= S_i;
        rand_leader_index = floor(N*rand()+1);
        X_rand = Positions(rand_leader_index, :);
        X_new = TargetPosition+10*S_i_total+rand*.00005*((TargetPosition+.005*X_rand)/2-Positions(i,:));
        X_new=LF(X_new,TargetPosition,dim);
        Positions_temp(i,:)=X_new;
        NN(i)=NeighborN;
    end
    Positions=Positions_temp;
    for i=1:size(Positions,1)
        PositionsFitness(1,i) = fobj(Positions(i,:));
        FES=FES+1;
    end
    [xminn,x_pos_min]=min(PositionsFitness);
    if xminn<TargetFitness
        TargetPosition=Positions(x_pos_min,:);
        TargetFitness=xminn;
    end
    conver_iter(l)=TargetFitness;
    disp(['IterationLFD'  num2str(l), ' : Best Cost = ', num2str(TargetFitness)]);
    l = l + 1;
end
t=cputime-t0;
end

function pos=LF(pos,Pos_target,dim)
beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
for j=1:dim
    u=rand*sigma;
    v=rand;
    step=u./abs(v).^(1/beta);
    stepsize=0.01*step.*(pos(j)-Pos_target(j));
    pos(j)= pos(j)+stepsize.*rand;
end
end


